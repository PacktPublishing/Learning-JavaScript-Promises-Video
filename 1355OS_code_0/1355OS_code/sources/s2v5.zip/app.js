

var promiseA = new Promise(function(resolve, reject) {
  var randomTime = Math.random() * 3000;
  setTimeout(resolve, randomTime);
});


var promiseB = new Promise(function(resolve, reject) {
  var randomTime = Math.random() * 3000;
  setTimeout(reject, randomTime);
});

var promiseC = new Promise(function(resolve, reject) {
  resolve(42, 'anything');
  resolve(50, 'anything else');
});



var geolocationPromise;
function getGeolocation() {
  if(!geolocationPromise) {
    geolocationPromise = new Promise(function(resolve, reject){
      navigator.geolocation.getCurrentPosition(resolve, reject);
    });
  }
  return geolocationPromise;
}


angular.module('SmashBoard', []).controller('TvController', function($scope, $http) {
  var now = Math.floor(new Date().getTime() / 1000);
  var url = 'http://redape.cloudapp.net/tvguidea/singleslot/'+now+'?channels=[1,159,63,64]&format=json&o=1'
  var ajaxPromise = $http.get(url);
  ajaxPromise.then(function weGotData(response) {
    $scope.channels = response.data.events;
  });
})
.controller('LocationController', function($scope, LocationService){
  LocationService.getGeolocation().then(function geolocationReceived(geoposition) {
    $scope.coordinates = geoposition.coords;
    $scope.$digest();
  }).catch(function(){
    $scope.coordinates = {latitude: 'N/A', longitude: 'N/A'};
    $scope.$digest();
  });
}).factory('LocationService', function($q) {
  return {
    getGeolocation: function() {
      return getGeolocation();
    }
  };
});
document.addEventListener("DOMContentLoaded", function(event) {

});
document.addEventListener("DOMContentLoaded", function(event) {
  var input = document.getElementById('city-input');
  var city = document.getElementById('city-name');
  var rejectFunction;
  input.addEventListener('keyup', function() {
    if(rejectFunction) {
      rejectFunction();
    }
    var myPromise = new Promise(function(resolve, reject){
      rejectFunction = reject;
      var start = new Date();
      var client = new XMLHttpRequest();
      client.onload = function() {
        resolve([JSON.parse(this.response).results[0], new Date() - start]);
      }
      var url = 'https://maps.googleapis.com/maps/api/geocode/json?address='+input.value+'&sensor=false';
      client.open('GET', url);
      client.send();
    });

    myPromise.then(function(data) {
      var result = data[0];
      var duration = data[1];
      console.log(result, duration);
      console.debug('Call completed before key press');
      if(result) {
        city.innerText = result.formatted_address;
        document.getElementById('load-time').innerText = duration/1000 + 's';
      }
    })
  })
});
document.addEventListener("DOMContentLoaded", function(event) {
  var charging = document.getElementById('charging');
  var level = document.getElementById('battery-level');

  navigator.getBattery().then(function(batteryManager) {
    // console.log(batteryManager);
    charging.innerText = batteryManager.charging  ? 'Yes' : 'No';
    level.innerText = (batteryManager.level * 100)+'%';
    level.className = 'fa fa-battery-' + Math.round(batteryManager.level * 4);
  })
});
document.addEventListener("DOMContentLoaded", function(event) {
  var click = document.getElementById('click-me');
  var last = document.getElementById('last');
  click.addEventListener('mousedown', function() {
    var clicking = new Promise(function executor(resolve, reject) {
      var start = new Date();
      click.onmouseout = reject;

      click.onmouseup = function() {
        console.debug('Mouse out');
        resolve(new Date() - start);
      }
    });

    clicking.then(function(duration) {
      last.innerText = (duration/1000) + ' seconds';
    }, function(message) {
      window.alert('Challenge incomplete');
    })
  })
});
document.addEventListener("DOMContentLoaded", function(event) {
  var input = document.getElementById('say-what');
  var output = document.getElementById('status');
  input.addEventListener('blur', function() {
    console.debug('Exited input');
    var speaking = new Promise(function executor(success, failure) {
      // var duration = Math.random() * 10000;
      // setTimeout(function() {
      //   success({
      //     elapsedTime: duration
      //   });
      // }, duration);
      var msg = new SpeechSynthesisUtterance(input.value);
      msg.onend = success;
      speechSynthesis.speak(msg);
    });
    output.innerText = 'Speaking';
    speaking.then(function(event) {
      console.debug(event);
      output.innerText = 'Speech completed in '+event.elapsedTime/1000+ ' seconds';
    });
  });
});
