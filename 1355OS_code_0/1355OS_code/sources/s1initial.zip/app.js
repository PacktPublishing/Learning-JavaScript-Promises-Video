angular.module('SmashBoard', [])
.controller('TvController', function($scope) {
    // API Url - Replace "now" with the current unix timestamp
    // var url = 'http://redape.cloudapp.net/tvguidea/singleslot/'+now+'?channels=[1,159,63,64]&format=json&o=1'
});
